

@extends('front.layout')
@section('title')
    الوظائف
@endsection
@section('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection
@section('content')

    <!-- this is content of the job-->
    <section class="container job-width">
        <div class="row">
            <div class="col-md-12 job-border">
                <div class="row">
                    <div class="bottom-border">
                        <div class="col-md-12">
                            <div class="row ">
                                <div class="col-md-10">
                                    <h6 class="blue">{{$data->title}} </h6>
                                    <div class="flex-job">
                                        <ul class="ul-job">
                                            <li class=" gray-color">
                                                                  <span>
                                                                      <i class="fa fa-briefcase" aria-hidden="true"></i>
                                                                  </span>
                                                الشركة
                                            </li>
                                            <li class=" gray-color">
                                                                  <span class="span-2">
                                                                      <i class="fa fa-map-marker" aria-hidden="true"></i>
                                                                  </span>
                                                مقر العمل
                                            </li>
                                            <li class=" gray-color">
                                                                  <span>
                                                                      <i class="fa fa-users" aria-hidden="true"></i>
                                                                  </span>
                                                العمالة المطلوبة
                                            </li>
                                        </ul>
                                        <ul class="ul-job-2">
                                            <li>
                                                {{$data->Company->company_name}}
                                            </li>
                                            <li>  {{$data->Country->name}} - {{$data->City->name}} </li>
                                            <li> {{$data->employees_count}} </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-2 job-center">
                                    <div class="img-job">
                                        @if(isset($data->Company->image))
                                            <img src="{{$data->Company->image}}" style="width:100px;height: 100px; border-radius: 50%;border: 2px #CCCCCC solid;" >
                                        @else
                                            <i class="fa fa-briefcase bag-job" aria-hidden="true"></i>
                                        @endif
                                    </div>
                                    <div class=" gray-color size-lighter">نشرت                                  {{\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $data->created_at)->diffForHumans()}}
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 margin-job">
                        <div class="row">
                            <div class="col-md-3 job-btn">
                                <button>شاهد المتقدمين</button>
                            </div>
                            <div class="col-md-9">
                                <ul class="ul-3">
                                    <li>
                                        <span>34</span>
                                        متقدمين
                                    </li>
                                    <li class="gray-color">
                                        <span>18</span>
                                        تم مشاهدتهم
                                    </li>
                                    <li class="green">
                                        <span>13</span>
                                        مناسبين
                                    </li>
                                    <li class="red">
                                        <span>1</span>
                                        مرفوضين
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 job-border">
                <div class="row">
                    <div class="col-md-12 move-h6">
                        <h6>متطلبات الوظيفة</h6>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-5 flex-job-ul">
                                <ul>

                                    <li class="gray-color">
                                        <span><i class="fa fa-user" aria-hidden="true"></i></span>
                                        مستوي الخبرة
                                    </li>
                                    <li class="gray-color">
                                        <span><i class="fa fa-calendar-o" aria-hidden="true"></i></span>
                                        سنين الخبرة
                                    </li>
                                    <li class="gray-color">
                                                            <span>
                                                                 <i class="fa fa-male" aria-hidden="true"></i>
                                                            </span>
                                        النوع
                                    </li>
                                    <li class="gray-color">
                                        <span><i class="fa fa-language" aria-hidden="true"></i></span>
                                        اللغة الإنجليزية
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                        <li>
                                            متوسطة
                                        </li>
                                        <li>
                                        1 - 3 سنوات
                                    </li>
                                    <li>
                                        ذكر
                                    </li>
                                    <li>
                                        أساسيات
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-7 flex-job-ul">
                                <ul>
                                    <li class="gray-color">
                                        <span><i class="fa fa-user" aria-hidden="true"></i></span>
                                        السن
                                    </li>
                                    <li class="gray-color">
                                        <span><i class="fa fa-laptop" aria-hidden="true"></i></span>
                                        استعمال الحاسب
                                    </li>
                                    <li class="gray-color">
                                        <span><i class="fa fa-graduation-cap" aria-hidden="true"></i></span>
                                        المؤهل
                                    </li>

                                    <li class="gray-color">
                                        <span><i class="fa fa-windows" aria-hidden="true"></i></span>
                                        MS office
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        {{$data->min_salary}} - {{$data->max_salary}}
                                    </li>
                                    <li>
                                        جيد
                                    </li>
                                    <li>
                                        مؤهل عالي
                                    </li>
                                    <li>
                                        نعم
                                    </li>
                                </ul>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 job-border">
                <div class="row">
                    <div class="col-md-12 move-h6">
                        <h6>الراتب و نوع العمل</h6>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-5 flex-job-ul">
                                <ul>
                                    <li class="gray-color">
                                        <span><i class="fa fa-credit-card-alt" aria-hidden="true"></i></span>
                                        الراتب الأساسي
                                    </li>
                                    <li class="gray-color">
                                        <span><i class="fa fa-money" aria-hidden="true"></i></span>
                                        الحوافز الإضافية
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        4000 - 4500 جنيه مصري
                                    </li>
                                    <li>
                                        2000 - 3000 جنيه مصري
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-7 flex-job-ul">
                                <ul>
                                    <li class="gray-color">
                                        <span><i class="fa fa-clock-o" aria-hidden="true"></i></span>
                                        نوع الوظيفة
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        يوم كامل
                                    </li>
                                </ul>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 job-border">
                <div class="row">
                    <div class="col-md-12 move-h6">
                        <h6>مميزات الوظيفة</h6>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-5 flex-job-ul">
                                <ul>
                                    <li>
                                        <span><i class="fa fa-stethoscope" aria-hidden="true"></i></span>
                                        تأمينات صحية
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-7 flex-job-ul">
                                <ul>
                                    <li>
                                        <span><i class="fa fa-users" aria-hidden="true"></i></span>
                                        تأمينات إجتماعية
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 job-border">
                <div class="row">
                    <div class="col-md-12 move-h6">
                        <h6>الراتب و نوع العمل</h6>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-5 flex-job-ul">
                                <ul>
                                    <li class="gray-color">
                                        <span><i class="fa fa-wrench" aria-hidden="true"></i></span>
                                        مجال الوظيفة
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        تسوق و مبيعات
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-7 flex-job-ul">
                                <ul>
                                    <li class="gray-color">
                                        <span><i class="fa fa-cog" aria-hidden="true"></i></span>
                                        تخصص الوظيفة
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        مبيعات خارجية و توزيع
                                    </li>
                                </ul>

                            </div>

                        </div>
                        <div clss="row">
                            <div class="col-md-12 flex-job-ul">
                                <ul>
                                    <li class="gray-color padding-left1">
                                        <span><i class="fa fa-outdent" aria-hidden="true"></i></span>
                                        التفاصيل
                                    </li>
                                </ul>
                                <ul class="size-ul">
                                    <li>
                                        مسئول عن زيادة عدد العملاء و تقديم أفضل خدمة ليهم
                                        خبرة لا تقل سنة في التمويل - تقدر على العمل الميداني
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <section class="container-fluied main-1">
                <section class="container">
                    <h3 class="h3">"وظائف مثل وظيفة"مسئول إئتمان خارجي </h3>
                    <section >
                        <div class="row">
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>

                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>
                            <div class="col-md-3  ">
                                <div class="box">
                                    <li>مصمم جرافيكس </li>
                                    <li><span><i class="fa fa-briefcase"></i>شركة أوراسكم</span> </li>
                                    <li><i class="fa fa-map-marker"></i>مصر - العاشر من رمضان - المدينة الصناعية</li>
                                    <li><i class="fa fa-calendar"></i>منذ 2 يوم</li>
                                </div>
                            </div>

                        </div>
                    </section>
                    <a href="#" target="_blank"> شاهد جميع الوظائف الجديدة على مطلوب...</a>
                </section>
            </section>
        </div>
    </section>


@endsection
