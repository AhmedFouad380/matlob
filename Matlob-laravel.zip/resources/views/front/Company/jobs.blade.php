

@extends('front.layout')
@section('title')
    الوظائف
@endsection
@section('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css" integrity="sha512-EZSUkJWTjzDlspOoPSpUFR0o0Xy7jdzW//6qhUkoZ9c4StFkVsp9fbbd0O06p9ELS3H486m4wmrCELjza4JEog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection
@section('content')



<!-- this is content of company -->
<section class="container container-space">
    <div class="row">
       @include('front.Company.sidebar')
        <div class="col-md-8">
            <!-- row -->
            <div class="col-md-12">
                <div class="row jobs">
                    <div class="col-md-6">
                        <h5> الوظائف
                            <span>({{$data->count()}})</span>
                        </h5>
                    </div>
                    <div class="col-md-6 leftbtn">
                        <a href="{{url('AddJob')}}" class="btn btn-primary">
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            إضافة وظيفة جديدة
                        </a>
                    </div >
                </div>
            </div>
            @foreach($data as $job)
            <div class="col-md-12 new-job">
                <div class="row">
                    <div class="col-md-1">
                        @if(isset($job->Company->image))
                            <img src="{{$job->Company->image}}" style="width:100px;height: 100px; border-radius: 50%;border: 2px #CCCCCC solid;" >
                        @else
                            <i class="fa fa-briefcase bag-job" aria-hidden="true"></i>
                        @endif
                    </div>
                    <div class="col-md-7">
                        <ul>
                            <li class="li-1">
                                {{$job->title}}
                            </li>
                            <li class="describe">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                {{$job->Country->name}} - {{$job->City->name}}
                            </li>
                            <li class="li-2" >
                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                                {{\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $job->created_at)->diffForHumans()}}
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 job-flex-1">
                        <ul class="job-flex">
                            <li class="li-3">
                                <div>
                                    <i class="fa fa-pencil-square-o" style="color:#4997D2" aria-hidden="true"></i>
                                    <br>
                                    <button data-id="{{$job->edit}}" class="edit" >تعديل</button>
                                </div>
                            </li>
                            <li class="li-4">
                                <div>
                                    <a href="{{url('jobDetails',$job->id)}}" class="show" >
                                        <i class="fa fa-eye-slash" style="color:#C3CCDC" aria-hidden="true"></i>
<br>
                                        عرض
                                    </a>
                                </div>
                            </li>
                            <li class="li-5">
                                <div>
                                    <button data-id="{{$job->id}}" class="delete">
                                    <i class="fa fa-trash-o" style="color:#D41111" aria-hidden="true"></i>
                                    <br>
                                    حذف</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            @endforeach
            {!! $data->links() !!}
        </div>
    </div>
</section>

@endsection
@section('js')
    <script type="text/javascript">

        $(".delete").on("click", function () {
            var dataList = [];
             dataList.push($(this).data('id'));

            if (dataList.length > 0) {
                Swal.fire({
                    title: "تحذير.هل انت متأكد؟!",
                    text: "",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#f64e60",
                    confirmButtonText: "نعم",
                    cancelButtonText: "لا",
                    closeOnConfirm: false,
                    closeOnCancel: false
                }).then(function (result) {
                    if (result.value) {
                        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                        $.ajax({
                            url: '{{url("delete-Job")}}',
                            type: "get",
                            data: {'id': dataList, _token: CSRF_TOKEN},
                            dataType: "JSON",
                            success: function (data) {
                                if (data.message == "Success") {
                                    $("input:checkbox:checked").parents("tr").remove();
                                    Swal.fire("نجاح", "تم الحذف بنجاح", "success");
                                    location.reload();
                                } else {
                                    Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                                }
                            },
                            fail: function (xhrerrorThrown) {
                                Swal.fire("نأسف", "حدث خطأ ما اثناء الحذف", "error");
                            }
                        });
                        // result.dismiss can be 'cancel', 'overlay',
                        // 'close', and 'timer'
                    } else if (result.dismiss === 'cancel') {
                        Swal.fire("ألغاء", "تم الالغاء", "error");
                    }
                });
            }
        });
    </script>

@endsection
