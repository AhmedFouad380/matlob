<div class="col-md-2">
    <ul class="company-data">
        <li @if(Request::segment(1) == 'Profile') class="blue gray first-li" @endif >حساب الشركة</li>
        <li @if(Request::segment(1) == 'Company-jobs') class="blue gray " @endif >الوظائف</li>
        <li>التقارير</li>
        <li>الحسابات</li>
        <li>الشكاوي</li>
    </ul>
</div>
