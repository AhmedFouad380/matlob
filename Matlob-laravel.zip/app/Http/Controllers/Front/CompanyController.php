<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Job;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Auth;
class CompanyController extends Controller
{


    public function registerCompany (Request $request){
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'password' => 'required|confirmed|min:6',
            'company_name' => 'required|unique:companies',
            'phone' => 'required|unique:companies',
//            'birth_date' => 'required',
            'country_id' => 'required',
            'city_id' => 'required',
            'state_id' => 'required',
            'village_id' => 'required',

        ]);

        $data = new Company();
        $data->first_name=$request->first_name;
        $data->last_name=$request->last_name;
        $data->email=$request->email;
        $data->phone=$request->phone;
        $data->password=Hash::make($request->password);
    //        $data->birth_date=$request->birth_date;
        $data->is_active=1;
        $data->country_id=$request->country_id;
        $data->city_id=$request->city_id;
        $data->state_id=$request->state_id;
        $data->village_id=$request->village_id;
        $data->employees_count=$request->employees_count;
        $data->tax_card_number=$request->tax_card_number;
        $data->tax_card_image=$request->tax_card_image;
        $data->commercial_registration_number=$request->commercial_registration_number;
        $data->commercial_registration_image=$request->commercial_registration_image;
        $data->verification_letter_image=$request->verification_letter_image;
        $data->employment_agreement	=$request->employment_agreement	;
        $data->company_name	=$request->company_name	;
        $data->image=$request->image;
        $data->email=$request->email;
        $data->phone=$request->phone;
        $data->other_phone=$request->other_phone;
        $data->experience_category_id =$request->experience_category_id ;
        $data->save();

//    Auth::guard('company')->login($data);
        return back()->with('messageSuccess','تم تسجيل الحساب بنجاح برجاء بتسجيل الدخول  ');
    }
    public function UpdateCompany(Request $request){

        $data =  Company::find($request->id);
        if($request->first_name){
            $data->first_name=$request->first_name;
        }
        if($request->last_name){
            $data->last_name=$request->last_name;
        }
        if($request->email){
            $data->email=$request->email;
        }
        if($request->phone){
            $data->phone=$request->phone;
        }
        if($request->password){
            $data->password=Hash::make($request->password);
        }
        if($request->country_id){
            $data->country_id=$request->country_id;
        }
        if($request->city_id){
            $data->city_id=$request->city_id;
        }
        if($request->state_id){
            $data->state_id=$request->state_id;
        }
        if($request->village_id){
            $data->village_id=$request->village_id;
        }
        if($request->employees_count){
            $data->employees_count=$request->employees_count;
        }
        if($request->tax_card_number){
            $data->tax_card_number=$request->tax_card_number;
        }
        if($request->tax_card_image){
            $data->tax_card_image=$request->tax_card_image;
        }
        if($request->commercial_registration_number){
            $data->commercial_registration_number=$request->commercial_registration_number;
        }
        if($request->verification_letter_image){
            $data->verification_letter_image=$request->verification_letter_image;
        }
        if($request->commercial_registration_image){
            $data->commercial_registration_image=$request->commercial_registration_image;
        }
        if($request->employment_agreement){
            $data->employment_agreement=$request->employment_agreement;
        }
        if($request->company_name){
            $data->company_name=$request->company_name;
        }
        if($request->other_phone){
            $data->other_phone=$request->other_phone;
        }
        if($request->experience_category_id){
            $data->experience_category_id=$request->experience_category_id;
        }
        if($request->image){
            $data->image=$request->image;
        }
        if($request->facebook){
            $data->facebook=$request->facebook;
        }

        if($request->twitter){
            $data->twitter=$request->twitter;
        }
        if($request->youtube){
            $data->youtube=$request->youtube;
        }
        if($request->instagram){
            $data->instagram=$request->instagram;
        }
        if($request->active_profile){
            $data->active_profile=$request->active_profile;
        }
        if($request->website){
            $data->website=$request->website;
        }
        $data->save();

        return back()->with('messageSuccess','تم التعديل بنجاح   ');
    }
    public function Profile(){
        $data = Auth::guard('company')->user();
        return view('front.Company.Profile',compact('data'));
    }

    public function CompanyJobs(){
            $data = Job::where('company_id',Auth::guard('company')->id())->paginate(10);
        return view('front.Company.jobs',compact('data'));
    }

    public function AddJob(){

        return view('front.Company.addJob');
    }
    public function jobDetails($id){
        $data = Job::FindOrFail($id);

        return view('front.Company.jobDetails',compact('data'));
    }

}
