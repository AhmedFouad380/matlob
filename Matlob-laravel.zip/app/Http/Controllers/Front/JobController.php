<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Job;
use App\Models\JobFeatures;
use App\Models\JobFeaturesAnswer;
use App\Models\JobFeaturesRelation;
use App\Models\JobOtherRequirement;
use App\Models\JobOtherRequirementAnswer;
use App\Models\JobRequeirementRelation;
use Illuminate\Http\Request;
use Auth;
class JobController extends Controller
{
    public function StoreJob(Request $request){

        $data = new Job();
        $data->company_id=Auth::guard('company')->id();
        $data->title=$request->firstname;
        $data->employees_count=$request->employees_count;
        $data->job_time=$request->job_time;
        $data->is_active='active';
        $data->description=$request->description;
        $data->min_experience=$request->min_experience;
        $data->max_experience=$request->max_experience;
        $data->min_age=$request->min_age    ;
        $data->max_age=$request->max_age;
        $data->min_salary=$request->min_salary;
        $data->max_salary=$request->max_salary;
        $data->currency_id=$request->currency_id;
        $data->extra_min_salary	=$request->extra_min_salary	;
        $data->extra_max_salary=$request->extra_max_salary;
        $data->is_active_salary=$request->is_active_salary;
        $data->is_car_licenses=$request->is_car_licenses;
        $data->type_car_licenses=$request->type_car_licenses;
        $data->job_type_id=$request->job_type_id;
        $data->job_qualification_id=$request->job_qualification_id;
        $data->job_level_id=$request->job_level_id;
        $data->experience_category_id=$request->experience_category_id;
        $data->country_id=$request->country_id;
        $data->city_id=$request->city_id;
        $data->state_id=$request->state_id;
        $data->village_id=$request->village_id;
        $data->save();

        foreach(JobOtherRequirement::where('is_active','active')->get() as $other ){
            $name = 'JobOtherRequirement-'.$other->id;
            if(isset($request->$name)){
                $JobOtherRequirement = new JobRequeirementRelation();
                $JobOtherRequirement->job_id=$data->id;
                $JobOtherRequirement->job_requirement_id=JobOtherRequirementAnswer::findOrFail($request->$name)->job_other_requirement_id;
                $JobOtherRequirement->job_requirement_answers_id=$request->$name;
                $JobOtherRequirement->save();
            }
        }
        foreach(JobOtherRequirement::where('is_active','active')->get() as $other ){
            $name = 'JobFeatures-'.$other->id;
            if(isset($request->$name)) {
                        $JobOtherRequirement = new JobFeaturesRelation();
                        $JobOtherRequirement->job_id = $data->id;
                        $JobOtherRequirement->job_features_id = JobFeaturesAnswer::findOrFail($request->$name)->job_features_id;
                        $JobOtherRequirement->job_features_answers_id = $request->$name;
                        $JobOtherRequirement->save();
                }
            }

        return redirect('Company-jobs')->with('messageSuccess','تم الاضافه بنجاح   ');
    }
    public function deleteJob(Request $request){
        try {
            Job::whereIn('id', $request->id)->delete();
        } catch (\Exception $e) {
            return response()->json(['message' => 'Failed']);
        }
        return response()->json(['message' => 'Success']);
    }


}
